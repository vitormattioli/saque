# Saque

Página do clube de tênis do bairro. Site estático: `index.html` + pasta `media/`.

- Pré-cadastro: https://tally.so/r/4a7X8o
- Instagram: https://www.instagram.com/saque.club/

## Publicar no GitHub Pages
Settings → Pages → Deploy from a branch → `main` / `(root)`.

## Observações
- A lista de sócios e o "Quem joga hoje?" estão ocultos nesta versão, porque dependiam do banco do claude.ai. Quando a sua base estiver pronta, dá para religá-los.
- Os vídeos (`media/quadra.mp4` e `media/homem.mp4`) tocam em sequência, sem som e em loop.
